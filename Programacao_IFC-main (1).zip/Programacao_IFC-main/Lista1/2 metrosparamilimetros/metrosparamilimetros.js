const metros = parseInt(prompt("Metros a serem convertidos:"))

const milimetros = metros * 1000

document.write (`${metros}m em milimetros é igual a ${mm}mm.`)
