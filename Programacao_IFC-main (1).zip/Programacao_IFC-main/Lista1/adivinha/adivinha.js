document.write("Opa <br/> ")
nome = prompt("Qual é o seu nome?")

document.write(`Bom dia ${nome}`)