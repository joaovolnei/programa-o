const fahrenheit = Number(prompt("Digite a quantidade de graus celsius:"))

const celsius = (f - 32) * 5/9

document.write(`${fahrenheit} graus fahrenheit equivalem a ${celsius} graus celsius.`)