const celsius = Number(prompt("Digite a quantidade de graus celsius:"))

const fahrenheit = (c * 9/5) + 32 

document.write(`${celsius} graus celsius são iguais a ${fahrenheit} graus fahrenheit.`)