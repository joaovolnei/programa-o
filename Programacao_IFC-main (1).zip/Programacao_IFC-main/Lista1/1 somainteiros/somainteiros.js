const numero1 = parseInt(prompt("digite o primeiro valor inteiro: <br/>"))

const numero2 = parseInt(prompt("digite o segundo valor inteiro: <br/>"))

const soma = v1 + v2 

document.write(`a soma de ${numero1} e ${numero2} é igual a ${soma}`)