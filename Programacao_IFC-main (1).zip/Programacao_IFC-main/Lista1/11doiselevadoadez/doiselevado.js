const dois_elevado_a_dez = Math.pow(2,10)

const dois_elevado_a_dez_string = dois_elevado_a_dez.toString()

document.write(`2 elevado a 10 contém ${dois_elevado_a_dez_string.length} caracteres.`)